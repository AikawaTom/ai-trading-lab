/*
 * engine.js — ส่วนคำนวณทั้งหมด (ไม่แตะหน้าเว็บ ไม่แตะอินเทอร์เน็ต)
 * ตัวชี้วัด (MA, RSI), backtest, จำลอง DCA, พอร์ตเงินจำลอง และสรุปผลเป็นภาษาไทย
 *
 * ทุกอย่างเป็น "การจำลอง" ไม่มีการส่งคำสั่งซื้อขายจริงใด ๆ
 * candles = [{ t: "2026-01-31", c: 123.45 }, ...] เรียงจากเก่าไปใหม่
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Engine = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ---------------- ตัวชี้วัด ----------------
  function sma(values, n) {
    var out = new Array(values.length).fill(null), sum = 0;
    for (var i = 0; i < values.length; i++) {
      sum += values[i];
      if (i >= n) sum -= values[i - n];
      if (i >= n - 1) out[i] = sum / n;
    }
    return out;
  }

  // RSI แบบ Wilder (มาตรฐานเดียวกับแอปกราฟทั่วไป)
  function rsi(values, period) {
    var out = new Array(values.length).fill(null);
    if (values.length <= period) return out;
    var gain = 0, loss = 0;
    for (var i = 1; i <= period; i++) {
      var d = values[i] - values[i - 1];
      if (d >= 0) gain += d; else loss -= d;
    }
    var ag = gain / period, al = loss / period;
    out[period] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    for (var j = period + 1; j < values.length; j++) {
      var dd = values[j] - values[j - 1];
      ag = (ag * (period - 1) + Math.max(dd, 0)) / period;
      al = (al * (period - 1) + Math.max(-dd, 0)) / period;
      out[j] = al === 0 ? 100 : 100 - 100 / (1 + ag / al);
    }
    return out;
  }

  // ---------------- กลยุทธ์ ----------------
  // คืนค่า array ของ 1 (อยากถือ) / 0 (อยากถือเงินสด) ตามราคาปิดของแต่ละวัน
  var STRATEGIES = {
    ma_cross: {
      label: "เส้นค่าเฉลี่ยตัดกัน (MA Crossover)",
      short: "MA Crossover",
      desc: "ถือเมื่อเส้นค่าเฉลี่ยระยะสั้นอยู่เหนือเส้นระยะยาว (แนวโน้มขาขึ้น) และขายเมื่อตัดลงมาต่ำกว่า",
      params: [
        { key: "fast", label: "เส้นเร็ว (วัน)", value: 20, min: 2, max: 200, term: "ma" },
        { key: "slow", label: "เส้นช้า (วัน)", value: 50, min: 5, max: 400, term: "ma" }
      ],
      signal: function (closes, p) {
        var f = sma(closes, p.fast), s = sma(closes, p.slow);
        return closes.map(function (_, i) { return f[i] != null && s[i] != null && f[i] > s[i] ? 1 : 0; });
      }
    },
    rsi: {
      label: "RSI กลับตัว (ซื้อตอนขายมากเกินไป)",
      short: "RSI",
      desc: "ซื้อเมื่อ RSI ต่ำกว่าเส้นล่าง (คนขายมากเกินไป) แล้วถือจนกว่า RSI จะขึ้นเหนือเส้นบน (คนซื้อมากเกินไป) จึงขาย",
      params: [
        { key: "period", label: "จำนวนวันที่ใช้คำนวณ", value: 14, min: 2, max: 50, term: "rsi" },
        { key: "low", label: "เส้นล่าง (ซื้อ)", value: 30, min: 5, max: 50, term: "rsi" },
        { key: "high", label: "เส้นบน (ขาย)", value: 70, min: 50, max: 95, term: "rsi" }
      ],
      signal: function (closes, p) {
        var r = rsi(closes, p.period), hold = 0;
        return closes.map(function (_, i) {
          if (r[i] == null) return 0;
          if (!hold && r[i] < p.low) hold = 1;
          else if (hold && r[i] > p.high) hold = 0;
          return hold;
        });
      }
    },
    buy_hold: {
      label: "ซื้อแล้วถือยาว (Buy & Hold)",
      short: "Buy & Hold",
      desc: "ซื้อวันแรกแล้วถือยาวไม่ขายเลย ใช้เป็นเส้นฐานเทียบว่ากลยุทธ์อื่นเก่งกว่าการถือเฉย ๆ หรือไม่",
      params: [],
      signal: function (closes) { return closes.map(function () { return 1; }); }
    }
  };

  function paramsOf(key, override) {
    var p = {};
    STRATEGIES[key].params.forEach(function (d) { p[d.key] = d.value; });
    Object.keys(override || {}).forEach(function (k) {
      var v = Number(override[k]);
      if (isFinite(v)) p[k] = v;
    });
    return p;
  }

  function maxDrawdown(series) {
    var peak = -Infinity, dd = 0;
    series.forEach(function (v) {
      if (v > peak) peak = v;
      if (peak > 0) dd = Math.min(dd, (v - peak) / peak * 100);
    });
    return dd;
  }

  // ---------------- Backtest ----------------
  // สัญญาณจากราคาปิดวันนี้ → ซื้อ/ขายที่ราคาปิด "วันถัดไป" (ไม่แอบรู้อนาคต)
  function backtest(candles, key, override, opt) {
    if (!STRATEGIES[key]) throw new Error("ไม่รู้จักกลยุทธ์: " + key);
    opt = opt || {};
    var cash0 = opt.cash || 100000, fee = (opt.feePct == null ? 0.1 : opt.feePct) / 100;
    var closes = candles.map(function (c) { return c.c; });
    var p = paramsOf(key, override);
    var sig = STRATEGIES[key].signal(closes, p);

    var cash = cash0, qty = 0, entry = null, fees = 0, daysIn = 0;
    var trades = [], curve = [], closed = [];
    var bhQty = cash0 * (1 - fee) / closes[0];

    for (var i = 0; i < candles.length; i++) {
      var price = closes[i], want = i === 0 ? (key === "buy_hold" ? 1 : 0) : sig[i - 1];
      if (want && qty === 0 && cash > 0) {
        var f = cash * fee; fees += f;
        qty = (cash - f) / price; entry = price; cash = 0;
        trades.push({ t: candles[i].t, side: "buy", price: price });
      } else if (!want && qty > 0) {
        var gross = qty * price, f2 = gross * fee; fees += f2;
        cash = gross - f2;
        var pnl = (price / entry - 1) * 100;
        closed.push(pnl);
        trades.push({ t: candles[i].t, side: "sell", price: price, pnlPct: pnl });
        qty = 0; entry = null;
      }
      if (qty > 0) daysIn++;
      curve.push({ t: candles[i].t, equity: cash + qty * price, bh: bhQty * price });
    }

    var last = curve[curve.length - 1];
    var wins = closed.filter(function (x) { return x > 0; }).length;
    return {
      params: p,
      curve: curve,
      trades: trades,
      stats: {
        start: candles[0].t, end: last.t, days: candles.length,
        initial: cash0,
        final: last.equity,
        returnPct: (last.equity / cash0 - 1) * 100,
        bhFinal: last.bh,
        bhReturnPct: (last.bh / cash0 - 1) * 100,
        maxDDPct: maxDrawdown(curve.map(function (x) { return x.equity; })),
        bhMaxDDPct: maxDrawdown(curve.map(function (x) { return x.bh; })),
        buys: trades.filter(function (x) { return x.side === "buy"; }).length,
        closedTrades: closed.length,
        winRatePct: closed.length ? wins / closed.length * 100 : null,
        openPosition: qty > 0,
        exposurePct: daysIn / candles.length * 100,
        fees: fees
      }
    };
  }

  // ---------------- DCA ----------------
  // ซื้อจำนวนเงินเท่ากันทุกงวด (รายวัน / รายสัปดาห์ / รายเดือน) ที่ราคาปิดของวันนั้น
  // priceMult = ตัวคูณแปลงราคาเป็นบาท (เช่น อัตรา USD/THB) — ใช้ค่าเดียวตลอดช่วง
  function dca(candles, opt) {
    var amount = Number(opt.amount) || 500, freq = opt.freq || "weekly";
    var fee = (opt.feePct == null ? 0.1 : opt.feePct) / 100, mult = opt.priceMult || 1;
    var units = 0, invested = 0, buys = 0, feesPaid = 0, points = [], lastMonth = null;

    for (var i = 0; i < candles.length; i++) {
      var c = candles[i], price = c.c * mult, month = c.t.slice(0, 7), buyNow = false;
      if (freq === "daily") buyNow = true;
      else if (freq === "weekly") buyNow = i % 7 === 0;
      else if (freq === "monthly") buyNow = month !== lastMonth;
      lastMonth = month;
      if (buyNow) {
        var f = amount * fee;
        units += (amount - f) / price; invested += amount; feesPaid += f; buys++;
      }
      points.push({ t: c.t, invested: invested, value: units * price });
    }

    var first = candles[0].c * mult, lastP = candles[candles.length - 1].c * mult;
    var value = units * lastP;
    var lumpValue = invested * (1 - fee) / first * lastP;
    // "ขาดทุนหนักสุดระหว่างทาง" = ช่วงที่มูลค่าต่ำกว่าเงินที่ใส่ไปมากที่สุด
    var worst = 0, worstT = null;
    points.forEach(function (p) {
      if (p.invested > 0) {
        var g = (p.value / p.invested - 1) * 100;
        if (g < worst) { worst = g; worstT = p.t; }
      }
    });
    return {
      points: points,
      stats: {
        start: candles[0].t, end: candles[candles.length - 1].t,
        amount: amount, freq: freq, buys: buys,
        invested: invested, value: value,
        profit: value - invested,
        profitPct: invested ? (value / invested - 1) * 100 : 0,
        units: units,
        avgCost: units ? (invested - feesPaid) / units : 0,
        lastPrice: lastP,
        lumpValue: lumpValue,
        lumpPct: invested ? (lumpValue / invested - 1) * 100 : 0,
        worstPct: worst, worstT: worstT,
        fees: feesPaid
      }
    };
  }

  // ---------------- พอร์ตเงินจำลอง ----------------
  // เก็บเป็น object ธรรมดา (หน้าเว็บจะบันทึกลง localStorage ของเครื่องนั้น ๆ)
  function newPortfolio(cash) {
    cash = Number(cash) || 100000;
    return { v: 1, startCash: cash, cash: cash, holdings: {}, history: [], created: new Date().toISOString() };
  }

  // priceThb = ราคาต่อหน่วยเป็นบาท ณ ตอนกด
  function pfBuy(pf, o) {
    var amt = Number(o.amountThb), fee = (o.feePct == null ? 0.1 : o.feePct) / 100;
    if (!(amt > 0)) throw new Error("ใส่จำนวนเงินที่จะซื้อก่อน");
    if (amt > pf.cash + 1e-6) throw new Error("เงินสดจำลองไม่พอ (เหลือ " + Math.floor(pf.cash).toLocaleString("th-TH") + " บาท)");
    if (!(o.priceThb > 0)) throw new Error("ยังไม่มีราคาล่าสุด ลองกดรีเฟรชราคา");
    var f = amt * fee, qty = (amt - f) / o.priceThb;
    var h = pf.holdings[o.key] || { market: o.market, symbol: o.symbol, short: o.short, qty: 0, cost: 0 };
    h.qty += qty; h.cost += amt; // cost = เงินที่จ่ายไปทั้งหมดรวมค่าธรรมเนียม
    pf.holdings[o.key] = h;
    pf.cash -= amt;
    pf.history.unshift({ t: new Date().toISOString(), side: "buy", key: o.key, short: o.short, price: o.priceThb, qty: qty, thb: amt, fee: f });
    pf.history = pf.history.slice(0, 200);
    return pf;
  }

  function pfSell(pf, o) {
    var h = pf.holdings[o.key], fee = (o.feePct == null ? 0.1 : o.feePct) / 100;
    if (!h || h.qty <= 0) throw new Error("ยังไม่ได้ถือตัวนี้อยู่");
    if (!(o.priceThb > 0)) throw new Error("ยังไม่มีราคาล่าสุด ลองกดรีเฟรชราคา");
    var qty = o.all ? h.qty : Math.min(h.qty, Number(o.amountThb) / o.priceThb);
    if (!(qty > 0)) throw new Error("ใส่จำนวนเงินที่จะขายก่อน");
    var gross = qty * o.priceThb, f = gross * fee, costPart = h.cost * (qty / h.qty);
    var pnl = gross - f - costPart;
    var origQty = h.qty;
    h.qty -= qty; h.cost -= costPart;
    if (o.all || h.qty <= origQty * 1e-9) delete pf.holdings[o.key];
    pf.cash += gross - f;
    pf.history.unshift({ t: new Date().toISOString(), side: "sell", key: o.key, short: h.short, price: o.priceThb, qty: qty, thb: gross - f, fee: f, pnl: pnl });
    pf.history = pf.history.slice(0, 200);
    return pf;
  }

  // pricesThb = { key: ราคาต่อหน่วยเป็นบาท }
  function pfSummary(pf, pricesThb) {
    var rows = [], holdValue = 0, missing = false;
    Object.keys(pf.holdings).forEach(function (k) {
      var h = pf.holdings[k], p = pricesThb[k];
      var value = p ? h.qty * p : null;
      if (value == null) missing = true; else holdValue += value;
      rows.push({
        key: k, market: h.market, symbol: h.symbol, short: h.short, qty: h.qty,
        avgCost: h.cost / h.qty, price: p || null, value: value, cost: h.cost,
        pnl: value == null ? null : value - h.cost,
        pnlPct: value == null ? null : (value / h.cost - 1) * 100
      });
    });
    var total = pf.cash + holdValue;
    return {
      cash: pf.cash, holdValue: holdValue, total: total, startCash: pf.startCash,
      pnl: total - pf.startCash, pnlPct: (total / pf.startCash - 1) * 100,
      rows: rows, missingPrice: missing
    };
  }

  // ---------------- สรุปผลเป็นภาษาคน ----------------
  function pct(x) { return (x >= 0 ? "+" : "") + x.toFixed(1) + "%"; }

  function explainBacktest(r, strategyKey) {
    var s = r.stats, lines = [];
    var name = STRATEGIES[strategyKey].short;
    if (strategyKey === "buy_hold") {
      lines.push("ถ้าซื้อวันแรกแล้วถือไว้เฉย ๆ ตลอดช่วงนี้ ผลตอบแทนคือ " + pct(s.returnPct));
    } else {
      var diff = s.returnPct - s.bhReturnPct;
      lines.push("กลยุทธ์ " + name + " ได้ " + pct(s.returnPct) + " เทียบกับซื้อแล้วถือเฉย ๆ ที่ได้ " + pct(s.bhReturnPct));
      if (Math.abs(diff) < 2) lines.push("ผลออกมาพอ ๆ กับการถือเฉย ๆ ในช่วงนี้");
      else if (diff > 0) lines.push("ช่วงนี้กลยุทธ์ทำได้ดีกว่าการถือเฉย ๆ ประมาณ " + diff.toFixed(1) + " จุดเปอร์เซ็นต์");
      else lines.push("ช่วงนี้กลยุทธ์ทำได้แย่กว่าการถือเฉย ๆ ประมาณ " + Math.abs(diff).toFixed(1) + " จุดเปอร์เซ็นต์" + (s.bhReturnPct > 20 ? " — เรื่องปกติในช่วงที่ราคาขึ้นแรง เพราะกลยุทธ์มักขายออกเร็วเกินไป" : ""));
      if (s.maxDDPct > s.bhMaxDDPct + 2) lines.push("ข้อดีคือช่วงที่ตลาดร่วงหนัก พอร์ตลดลงน้อยกว่า (" + s.maxDDPct.toFixed(1) + "% เทียบกับ " + s.bhMaxDDPct.toFixed(1) + "%)");
      if (s.closedTrades === 0 && s.buys === 0) lines.push("ช่วงนี้ไม่มีสัญญาณซื้อเลย ลองขยายช่วงเวลาหรือปรับตัวเลข");
      else if (s.winRatePct != null) lines.push("เทรดจบไป " + s.closedTrades + " รอบ ได้กำไร " + Math.round(s.winRatePct) + "% ของจำนวนรอบ" + (s.openPosition ? " (ตอนนี้ยังถืออยู่ 1 รอบ)" : ""));
      lines.push("ถือของอยู่ประมาณ " + Math.round(s.exposurePct) + "% ของจำนวนวัน ที่เหลือถือเงินสด");
    }
    lines.push("จำไว้: ผลในอดีตไม่ได้บอกว่าอนาคตจะออกมาแบบเดียวกัน");
    return lines;
  }

  function explainDca(r, short) {
    var s = r.stats, lines = [];
    var freqTh = { daily: "ทุกวัน", weekly: "ทุกสัปดาห์", monthly: "ทุกเดือน" }[s.freq];
    lines.push("ถ้าซื้อ " + short + " " + freqTh + " ครั้งละ " + s.amount.toLocaleString("th-TH") + " บาท รวม " + s.buys + " ครั้ง จะใส่เงินไปทั้งหมด " + Math.round(s.invested).toLocaleString("th-TH") + " บาท");
    lines.push("วันนี้จะมีมูลค่า " + Math.round(s.value).toLocaleString("th-TH") + " บาท (" + pct(s.profitPct) + ")");
    if (s.worstT) lines.push("ช่วงที่แย่ที่สุด มูลค่าเคยต่ำกว่าเงินที่ใส่ไป " + Math.abs(s.worstPct).toFixed(1) + "% — ต้องใจนิ่งพอที่จะไม่ขายทิ้งตอนนั้น");
    if (Math.abs(s.profitPct - s.lumpPct) >= 1) {
      lines.push(s.lumpPct > s.profitPct
        ? "ถ้าเอาเงินก้อนเดียวกันซื้อทีเดียวตั้งแต่วันแรกจะได้ " + pct(s.lumpPct) + " (ดีกว่าในช่วงนี้) แต่ DCA ช่วยลดความเสี่ยงเรื่องซื้อผิดจังหวะ"
        : "ถ้าซื้อทีเดียวตั้งแต่วันแรกจะได้แค่ " + pct(s.lumpPct) + " — DCA ช่วยเฉลี่ยต้นทุนให้ดีกว่าในช่วงนี้");
    }
    lines.push("จำไว้: ผลในอดีตไม่ได้บอกว่าอนาคตจะออกมาแบบเดียวกัน");
    return lines;
  }

  return {
    sma: sma, rsi: rsi, STRATEGIES: STRATEGIES, paramsOf: paramsOf, maxDrawdown: maxDrawdown,
    backtest: backtest, dca: dca,
    newPortfolio: newPortfolio, pfBuy: pfBuy, pfSell: pfSell, pfSummary: pfSummary,
    explainBacktest: explainBacktest, explainDca: explainDca
  };
});
