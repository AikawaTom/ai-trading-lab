/*
 * chart.js — กราฟเส้นแบบ SVG ที่เขียนเอง (ไม่ต้องโหลดไลบรารีจากเน็ต)
 * LineChart(el, { labels: [...], series: [{ values, color, label, fill }], fmt })
 * แตะ/ลากนิ้วบนกราฟเพื่อดูค่าแต่ละวัน
 */
(function (root) {
  "use strict";
  var NS = "http://www.w3.org/2000/svg";

  function mk(tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }

  function niceTicks(min, max, n) {
    if (min === max) { min -= 1; max += 1; }
    var span = max - min, step = Math.pow(10, Math.floor(Math.log10(span / n)));
    var err = span / n / step;
    if (err >= 7.5) step *= 10; else if (err >= 3.5) step *= 5; else if (err >= 1.5) step *= 2;
    var lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step, out = [];
    for (var v = lo; v <= hi + step / 2; v += step) out.push(+v.toPrecision(12));
    return out;
  }

  function shortDate(s) {
    var m = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
    var p = String(s).split("-");
    return +p[2] + " " + m[+p[1] - 1] + " " + String(+p[0] + 543).slice(2);
  }

  function LineChart(el, opt) {
    this.el = el; this.opt = opt;
    var self = this;
    this._onResize = function () { self.draw(); };
    if (typeof ResizeObserver !== "undefined") {
      this._ro = new ResizeObserver(this._onResize); this._ro.observe(el);
    } else window.addEventListener("resize", this._onResize);
    this.draw();
  }

  LineChart.prototype.destroy = function () {
    if (this._ro) this._ro.disconnect(); else window.removeEventListener("resize", this._onResize);
    this.el.innerHTML = "";
  };

  LineChart.prototype.draw = function () {
    var el = this.el, o = this.opt, W = Math.max(el.clientWidth, 260), H = el.clientHeight || 220;
    if (this._lastW === W && this._drawn) return;
    this._lastW = W; this._drawn = true;
    el.innerHTML = "";
    var fmt = o.fmt || function (v) { return v.toLocaleString("th-TH", { maximumFractionDigits: 2 }); };
    var labels = o.labels, n = labels.length;
    if (!n) { el.innerHTML = '<div class="chart-empty">ไม่มีข้อมูล</div>'; return; }

    var all = [];
    o.series.forEach(function (s) { s.values.forEach(function (v) { if (v != null && isFinite(v)) all.push(v); }); });
    var ticks = niceTicks(Math.min.apply(null, all), Math.max.apply(null, all), 4);
    var yMin = ticks[0], yMax = ticks[ticks.length - 1];

    var padL = 8, padR = 8, padT = 10, padB = 22;
    var axisW = Math.max.apply(null, ticks.map(function (t) { return fmt(t).length; })) * 6.4 + 8;
    var x0 = padL, x1 = W - padR - axisW, y0 = padT, y1 = H - padB;
    var X = function (i) { return x0 + (n === 1 ? 0 : i / (n - 1)) * (x1 - x0); };
    var Y = function (v) { return y1 - (v - yMin) / (yMax - yMin) * (y1 - y0); };

    var svg = mk("svg", { viewBox: "0 0 " + W + " " + H, width: W, height: H, class: "chart-svg", role: "img" });

    ticks.forEach(function (t) {
      svg.appendChild(mk("line", { x1: x0, x2: x1, y1: Y(t), y2: Y(t), class: "grid" }));
      var tx = mk("text", { x: x1 + 6, y: Y(t) + 4, class: "tick" }); tx.textContent = fmt(t); svg.appendChild(tx);
    });
    [0, Math.floor((n - 1) / 2), n - 1].forEach(function (i, k) {
      var tx = mk("text", { x: X(i), y: H - 5, class: "tick", "text-anchor": k === 0 ? "start" : k === 2 ? "end" : "middle" });
      tx.textContent = shortDate(labels[i]); svg.appendChild(tx);
    });

    o.series.forEach(function (s) {
      var d = "", started = false;
      s.values.forEach(function (v, i) {
        if (v == null || !isFinite(v)) { started = false; return; }
        d += (started ? "L" : "M") + X(i).toFixed(1) + " " + Y(v).toFixed(1) + " ";
        started = true;
      });
      if (s.fill) {
        var fi = s.values.findIndex(function (v) { return v != null; });
        svg.appendChild(mk("path", { d: d + "L" + X(n - 1).toFixed(1) + " " + y1 + " L" + X(fi).toFixed(1) + " " + y1 + " Z", fill: s.color, opacity: 0.12 }));
      }
      svg.appendChild(mk("path", { d: d, fill: "none", stroke: s.color, "stroke-width": s.width || 2, "stroke-linejoin": "round", "stroke-dasharray": s.dash || "" }));
    });

    var cross = mk("line", { y1: y0, y2: y1, class: "cross", visibility: "hidden" });
    svg.appendChild(cross);
    var dots = o.series.map(function (s) { var c = mk("circle", { r: 4, fill: s.color, visibility: "hidden" }); svg.appendChild(c); return c; });
    el.appendChild(svg);

    var tip = document.createElement("div"); tip.className = "chart-tip"; tip.hidden = true; el.appendChild(tip);

    function show(evt) {
      var r = svg.getBoundingClientRect(), px = (evt.touches ? evt.touches[0].clientX : evt.clientX) - r.left;
      var i = Math.round((px - x0) / (x1 - x0) * (n - 1));
      if (i < 0 || i >= n) return hide();
      cross.setAttribute("x1", X(i)); cross.setAttribute("x2", X(i)); cross.setAttribute("visibility", "visible");
      var html = "<b>" + shortDate(labels[i]) + "</b>";
      o.series.forEach(function (s, k) {
        var v = s.values[i];
        if (v == null) { dots[k].setAttribute("visibility", "hidden"); return; }
        dots[k].setAttribute("cx", X(i)); dots[k].setAttribute("cy", Y(v)); dots[k].setAttribute("visibility", "visible");
        html += '<div><i style="background:' + s.color + '"></i>' + (s.label ? s.label + ": " : "") + fmt(v) + "</div>";
      });
      tip.innerHTML = html; tip.hidden = false;
      var left = X(i) + 12; if (left + tip.offsetWidth > W) left = X(i) - tip.offsetWidth - 12;
      tip.style.left = Math.max(0, left) + "px";
    }
    function hide() {
      tip.hidden = true; cross.setAttribute("visibility", "hidden");
      dots.forEach(function (d) { d.setAttribute("visibility", "hidden"); });
    }
    svg.addEventListener("pointermove", show);
    svg.addEventListener("pointerdown", show);
    svg.addEventListener("pointerleave", hide);
    svg.addEventListener("touchmove", show, { passive: true });
  };

  root.LineChart = LineChart;
  root.shortDateTh = shortDate;
})(this);
