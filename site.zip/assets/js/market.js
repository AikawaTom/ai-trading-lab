/*
 * market.js — ดึงข้อมูลราคา (อ่านอย่างเดียว ไม่ต้องล็อกอิน ไม่มี API key)
 *  - คริปโต: Binance public market data (ราคา USDT) แบบสด
 *  - หุ้น: ไฟล์ data/stocks/*.json ที่ GitHub อัปเดตให้วันละ 2 รอบ (ราคาปิดล่าสุด)
 *  - อัตราแลกเปลี่ยน USD/THB: open.er-api.com (สด) หรือ data/fx.json (สำรอง)
 */
(function (root) {
  "use strict";

  var BINANCE = ["https://data-api.binance.vision", "https://api.binance.com"];
  var FX_LIVE = "https://open.er-api.com/v6/latest/USD";
  var goodBase = 0;
  var cache = {};

  function timeout(ms) {
    if (typeof AbortController === "undefined") return {};
    var c = new AbortController();
    setTimeout(function () { c.abort(); }, ms);
    return { signal: c.signal };
  }

  function getJSON(url, ms) {
    return fetch(url, Object.assign({ cache: "no-store" }, timeout(ms || 12000))).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }

  // ลองเซิร์ฟเวอร์ Binance ทีละตัว จำตัวที่ใช้ได้ไว้
  function binance(path) {
    var order = [goodBase].concat(BINANCE.map(function (_, i) { return i; }).filter(function (i) { return i !== goodBase; }));
    var i = 0;
    function next(err) {
      if (i >= order.length) return Promise.reject(err || new Error("เชื่อมต่อ Binance ไม่ได้"));
      var idx = order[i++];
      return getJSON(BINANCE[idx] + path).then(function (j) { goodBase = idx; return j; }, next);
    }
    return next();
  }

  function fileName(symbol) { return symbol.replace(/[^A-Za-z0-9]/g, "_"); }

  function currencyOf(market) {
    return market === "crypto" ? "USDT" : market === "stock_us" ? "USD" : "THB";
  }

  // ---------- อัตราแลกเปลี่ยน ----------
  var fxPromise = null, fxAt = 0;
  function fx() {
    if (fxPromise && Date.now() - fxAt < 10 * 60 * 1000) return fxPromise;
    fxAt = Date.now();
    fxPromise = getJSON(FX_LIVE, 8000).then(function (j) {
      if (!j || !j.rates || !(j.rates.THB > 0)) throw new Error("bad fx");
      return { rate: j.rates.THB, source: "สด", updated: j.time_last_update_utc || "" };
    }).catch(function () {
      return getJSON("data/fx.json").then(function (j) {
        if (!(j.usdthb > 0)) throw new Error("bad fx file");
        return { rate: j.usdthb, source: "ไฟล์รายวัน", updated: j.updated || "" };
      });
    }).catch(function () {
      fxPromise = null;
      return { rate: null, source: "ไม่มี", updated: "" };
    });
    return fxPromise;
  }

  function toThb(value, currency, fxInfo) {
    if (value == null) return null;
    if (currency === "THB") return value;
    return fxInfo && fxInfo.rate ? value * fxInfo.rate : null;
  }

  // ---------- หุ้น (ไฟล์ JSON ในเว็บ) ----------
  function stockFile(symbol) {
    var k = "stock:" + symbol;
    if (cache[k] && Date.now() - cache[k].at < 30 * 60 * 1000) return cache[k].p;
    var p = getJSON("data/stocks/" + fileName(symbol) + ".json").then(function (j) {
      if (!j.candles || !j.candles.length) throw new Error("empty");
      return j;
    }).catch(function () {
      delete cache[k];
      throw new Error("ยังไม่มีข้อมูลหุ้น " + symbol + " (ระบบจะอัปเดตข้อมูลหุ้นให้เองวันละ 2 รอบ)");
    });
    cache[k] = { p: p, at: Date.now() };
    return p;
  }

  // ---------- ราคาล่าสุด ----------
  // คืน { native, currency, changePct, asOf, live }
  function quote(market, symbol) {
    if (market === "crypto") {
      return binance("/api/v3/ticker/24hr?symbol=" + encodeURIComponent(symbol)).then(function (j) {
        return {
          native: parseFloat(j.lastPrice), currency: "USDT",
          changePct: parseFloat(j.priceChangePercent), asOf: new Date(), live: true
        };
      });
    }
    return stockFile(symbol).then(function (j) {
      var n = j.candles.length, last = j.candles[n - 1], prev = n > 1 ? j.candles[n - 2] : last;
      return {
        native: last[1], currency: j.currency || currencyOf(market),
        changePct: (last[1] / prev[1] - 1) * 100, asOf: last[0], live: false, updated: j.updated
      };
    });
  }

  // ---------- ข้อมูลย้อนหลังรายวัน ----------
  // คืน { candles: [{t, c}], currency }
  function history(market, symbol, days) {
    var k = "h:" + market + ":" + symbol + ":" + days;
    if (cache[k] && Date.now() - cache[k].at < 10 * 60 * 1000) return cache[k].p;
    var p;
    if (market === "crypto") {
      var start = Date.now() - days * 864e5, out = [];
      var step = function (from) {
        return binance("/api/v3/klines?symbol=" + encodeURIComponent(symbol) + "&interval=1d&limit=1000&startTime=" + from).then(function (rows) {
          rows.forEach(function (r) { out.push({ t: new Date(r[0]).toISOString().slice(0, 10), c: parseFloat(r[4]) }); });
          if (rows.length === 1000) return step(rows[rows.length - 1][0] + 864e5);
          return { candles: out, currency: "USDT" };
        });
      };
      p = step(start);
    } else {
      p = stockFile(symbol).then(function (j) {
        var cut = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
        return {
          candles: j.candles.filter(function (r) { return r[0] >= cut; }).map(function (r) { return { t: r[0], c: r[1] }; }),
          currency: j.currency || currencyOf(market)
        };
      });
    }
    p = p.catch(function (e) { delete cache[k]; throw e; });
    cache[k] = { p: p, at: Date.now() };
    return p;
  }

  function clearCache() { cache = {}; fxPromise = null; }

  root.Market = { fx: fx, toThb: toThb, quote: quote, history: history, currencyOf: currencyOf, clearCache: clearCache };
})(this);
