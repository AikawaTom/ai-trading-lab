/*
 * app.js — หน้าจอและการกดปุ่มทั้งหมด
 * ข้อมูลที่บันทึกไว้ในเครื่อง (localStorage): พอร์ตจำลอง, ตั้งค่า, แท็บ/เหรียญที่เลือกล่าสุด
 */
(function () {
  "use strict";
  var E = window.Engine, M = window.Market, G = window.GLOSSARY;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // ---------- เก็บข้อมูลในเครื่อง (กันพังถ้าเบราว์เซอร์ไม่ให้เก็บ) ----------
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  var S = {
    symbols: null,
    ui: store.get("atl-ui", { market: "crypto", symbol: "BTCUSDT", tab: "overview", range: 365 }),
    settings: store.get("atl-settings", { feePct: 0.1, startCash: 100000 }),
    pf: store.get("atl-pf", null),
    fx: null, quote: null, charts: {}
  };
  if (!S.pf || !S.pf.holdings) S.pf = E.newPortfolio(S.settings.startCash);
  function saveUi() { store.set("atl-ui", S.ui); }
  function savePf() { store.set("atl-pf", S.pf); }

  // ---------- รูปแบบตัวเลข ----------
  function nf(v, max, min) { return Number(v).toLocaleString("th-TH", { maximumFractionDigits: max, minimumFractionDigits: min || 0 }); }
  function money(v) { return v == null || !isFinite(v) ? "—" : Math.abs(v) >= 1000 ? nf(v, 0) : nf(v, 2, 2); }
  function price(v) {
    if (v == null || !isFinite(v)) return "—";
    var a = Math.abs(v);
    return a >= 100000 ? nf(v, 0) : a >= 10 ? nf(v, 2, 2) : a >= 1 ? nf(v, 4, 2) : nf(v, 8, 4);
  }
  function qty(v) { return nf(v, v >= 1 ? 4 : 8); }
  function pct(v) { if (v == null || !isFinite(v)) return "—"; if (Math.abs(v) < 0.0005) return "0.00%"; return (v > 0 ? "+" : "") + v.toFixed(Math.abs(v) < 0.1 ? 3 : 2) + "%"; }
  function cls(v) { return v == null ? "" : v >= 0 ? "up" : "down"; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function ti(term) { return G[term] ? '<button class="ti" data-term="' + term + '" aria-label="อธิบายคำนี้">i</button>' : ""; }
  function timeTh(d) { return d.toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" }); }

  var toastT;
  function toast(msg) {
    var t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove("show"); }, 2800);
  }

  function meta(market, symbol) {
    var list = (S.symbols && S.symbols[market]) || [];
    for (var i = 0; i < list.length; i++) if (list[i].symbol === symbol) return list[i];
    return { symbol: symbol, name: symbol, short: symbol.replace(/USDT$|\.BK$/, "") };
  }
  function keyOf(market, symbol) { return market + ":" + symbol; }
  function mult(currency) { return currency === "THB" ? 1 : S.fx && S.fx.rate ? S.fx.rate : null; }

  // ---------- แท็บ ----------
  function setTab(tab) {
    S.ui.tab = tab; saveUi();
    $$("[data-tab]").forEach(function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
    $$(".panel").forEach(function (p) { p.classList.toggle("on", p.dataset.panel === tab); });
    if (tab === "overview") loadOverview();
    if (tab === "paper") renderPaper();
    window.scrollTo({ top: 0 });
  }

  // ---------- เลือกตลาด / เหรียญ ----------
  function fillSymbols() {
    var list = S.symbols[S.ui.market] || [];
    if (!list.some(function (s) { return s.symbol === S.ui.symbol; })) S.ui.symbol = list[0].symbol;
    $("#symbol").innerHTML = list.map(function (s) {
      return '<option value="' + esc(s.symbol) + '">' + esc(s.short) + " · " + esc(s.name) + "</option>";
    }).join("");
    $("#symbol").value = S.ui.symbol;
    $$("#marketSeg button").forEach(function (b) { b.classList.toggle("on", b.dataset.market === S.ui.market); });
  }

  function selectSymbol(market, symbol) {
    S.ui.market = market; S.ui.symbol = symbol; saveUi();
    fillSymbols();
    onSymbolChange();
  }

  function onSymbolChange() {
    S.quote = null;
    $("#btResult").hidden = true; $("#dcaResult").hidden = true;
    refreshQuote().catch(function () {});
    if (S.ui.tab === "overview") loadOverview();
    if (S.ui.tab === "paper") renderPaper();
  }

  // ---------- ราคาล่าสุด ----------
  var quoteSeq = 0;
  function refreshQuote() {
    var seq = ++quoteSeq, m = S.ui.market, sym = S.ui.symbol, info = meta(m, sym);
    $("#qPrice").textContent = "…"; $("#qChg").textContent = ""; $("#qChg").className = "chg num";
    $("#tradeSym").textContent = info.short;
    return Promise.all([M.quote(m, sym), M.fx()]).then(function (r) {
      if (seq !== quoteSeq) return S.quote;
      var q = r[0]; S.fx = r[1];
      var k = mult(q.currency);
      q.thb = k ? q.native * k : null;
      S.quote = q;
      $("#qPrice").textContent = q.thb != null ? "฿" + price(q.thb) : price(q.native) + " " + q.currency;
      var sub = [];
      if (q.currency !== "THB") sub.push(price(q.native) + " " + q.currency + (S.fx.rate ? " · 1 USD = " + nf(S.fx.rate, 2) + " บาท" : " · ยังไม่มีอัตราแลกเปลี่ยน"));
      sub.push(q.live ? "สด " + timeTh(q.asOf) : "ราคาปิด " + window.shortDateTh(q.asOf));
      $("#qSub").textContent = sub.join(" · ");
      $("#qChg").textContent = pct(q.changePct) + (q.live ? " 24ชม." : "");
      $("#qChg").className = "chg num " + cls(q.changePct);
      updateTradeLine();
      return q;
    }).catch(function (e) {
      if (seq !== quoteSeq) return;
      $("#qPrice").textContent = "ดึงราคาไม่ได้";
      $("#qSub").textContent = e.message || "เช็กอินเทอร์เน็ตแล้วกดรีเฟรช";
      updateTradeLine();
      throw e;
    });
  }

  // ---------- ภาพรวม ----------
  var ovSeq = 0;
  function loadOverview() {
    var seq = ++ovSeq, m = S.ui.market, sym = S.ui.symbol, days = S.ui.range || 365;
    $$("#rangeChips button").forEach(function (b) { b.classList.toggle("on", +b.dataset.days === days); });
    var el = $("#priceChart");
    if (S.charts.price) { S.charts.price.destroy(); S.charts.price = null; }
    el.innerHTML = '<div class="chart-load">กำลังโหลดกราฟ…</div>';
    $("#facts").innerHTML = '<div class="empty">กำลังโหลด…</div>';
    Promise.all([M.history(m, sym, Math.max(days, 420)), M.fx()]).then(function (r) {
      if (seq !== ovSeq) return;
      S.fx = r[1];
      var h = r[0], k = mult(h.currency) || 1, all = h.candles;
      $("#chartUnit").textContent = mult(h.currency) ? "(บาท)" : "(" + h.currency + ")";
      var cut = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
      var view = all.filter(function (c) { return c.t >= cut; });
      el.innerHTML = "";
      S.charts.price = new window.LineChart(el, {
        labels: view.map(function (c) { return c.t; }),
        series: [{ values: view.map(function (c) { return c.c * k; }), color: "#3fb6a8", fill: true, label: "ราคา" }],
        fmt: shortMoney
      });
      renderFacts(all, k);
    }).catch(function (e) {
      if (seq !== ovSeq) return;
      el.innerHTML = '<div class="chart-empty">' + esc(e.message || "โหลดกราฟไม่ได้") + "</div>";
      $("#facts").innerHTML = '<div class="empty">ยังไม่มีข้อมูล</div>';
    });
  }

  function shortMoney(v) {
    var a = Math.abs(v);
    if (a >= 1e6) return nf(v / 1e6, 2) + "ล.";
    if (a >= 1e4) return nf(v / 1e3, 1) + "K";
    return nf(v, a >= 100 ? 0 : a >= 1 ? 2 : 4);
  }

  function renderFacts(candles, k) {
    var closes = candles.map(function (c) { return c.c; }), n = closes.length, last = closes[n - 1], out = [];
    function fact(tone, title, term, text) {
      out.push('<div class="fact"><i class="dot ' + tone + '"></i><div><b>' + title + " " + ti(term) + "</b><span>" + text + "</span></div></div>");
    }
    var ma50 = E.sma(closes, 50)[n - 1], ma200 = E.sma(closes, 200)[n - 1];
    if (ma50) {
      var d = (last / ma50 - 1) * 100;
      fact(d >= 0 ? "up" : "down", "แนวโน้มช่วง 2–3 เดือน: " + (d >= 0 ? "ขาขึ้น" : "ขาลง"), "ma",
        "ราคาอยู่" + (d >= 0 ? "เหนือ" : "ใต้") + "เส้นค่าเฉลี่ย 50 วัน " + Math.abs(d).toFixed(1) + "%");
    }
    if (ma50 && ma200) {
      fact(ma50 >= ma200 ? "up" : "down", "แนวโน้มระยะยาว: " + (ma50 >= ma200 ? "ขาขึ้น" : "ขาลง"), "ma",
        "เส้น 50 วันอยู่" + (ma50 >= ma200 ? "เหนือ" : "ใต้") + "เส้น 200 วัน (" + (ma50 >= ma200 ? "Golden Cross" : "Death Cross") + ")");
    }
    var r = E.rsi(closes, 14)[n - 1];
    if (r != null) {
      var zone = r < 30 ? ["down", "ต่ำ — ถูกขายมากเกินไป"] : r > 70 ? ["warn", "สูง — ถูกซื้อมากเกินไป"] : ["", "ปกติ"];
      fact(zone[0], "RSI ตอนนี้ " + r.toFixed(0) + " (" + zone[1] + ")", "rsi", "ต่ำกว่า 30 = คนขายมาก · สูงกว่า 70 = คนซื้อมาก");
    }
    var yr = closes.slice(-365), hi = Math.max.apply(null, yr), lo = Math.min.apply(null, yr);
    fact("", "ช่วง 1 ปี: ต่ำสุด ฿" + shortMoney(lo * k) + " · สูงสุด ฿" + shortMoney(hi * k), "drawdown",
      "ตอนนี้ต่ำกว่าจุดสูงสุด " + Math.abs((last / hi - 1) * 100).toFixed(1) + "% และสูงกว่าจุดต่ำสุด " + ((last / lo - 1) * 100).toFixed(1) + "%");
    var moves = [];
    for (var i = Math.max(1, n - 30); i < n; i++) moves.push(Math.abs(closes[i] / closes[i - 1] - 1) * 100);
    if (moves.length) {
      var avg = moves.reduce(function (a, b) { return a + b; }, 0) / moves.length;
      fact(avg > 3 ? "warn" : "", "ความผันผวน: ขึ้นลงเฉลี่ยวันละ " + avg.toFixed(1) + "%", "volatility",
        avg > 3 ? "แกว่งแรง ควรใส่เงินน้อย ๆ และใจเย็น" : avg > 1.5 ? "แกว่งปานกลาง" : "ค่อนข้างนิ่ง");
    }
    $("#facts").innerHTML = out.join("") || '<div class="empty">ข้อมูลยังไม่พอ</div>';
  }

  // ---------- เทรดจำลอง ----------
  function updateTradeLine() {
    var q = S.quote, info = meta(S.ui.market, S.ui.symbol);
    $("#tradeSym").textContent = info.short;
    $("#tradePriceLine").textContent = q && q.thb ? "ราคาตอนนี้ ฿" + price(q.thb) + " ต่อ 1 " + info.short + (q.live ? "" : " (ราคาปิดล่าสุด)") : "รอราคา…";
    var h = S.pf.holdings[keyOf(S.ui.market, S.ui.symbol)], mine = $("#mine");
    if (h) {
      var v = q && q.thb ? h.qty * q.thb : null;
      mine.hidden = false;
      mine.innerHTML = "ถืออยู่ <b class='num'>" + qty(h.qty) + " " + esc(info.short) + "</b>" +
        (v != null ? " · มูลค่า ฿" + money(v) + " <b class='" + cls(v - h.cost) + "'>" + pct((v / h.cost - 1) * 100) + "</b>" : "");
    } else mine.hidden = true;
  }

  var pfSeq = 0;
  function renderPaper() {
    $("#feeLabel").textContent = S.settings.feePct;
    updateTradeLine();
    var seq = ++pfSeq, keys = Object.keys(S.pf.holdings);
    drawPortfolio({});
    if (!keys.length) return;
    M.fx().then(function (fx) {
      S.fx = fx;
      return Promise.all(keys.map(function (k) {
        var h = S.pf.holdings[k];
        return M.quote(h.market, h.symbol).then(function (q) { var m = mult(q.currency); return [k, m ? q.native * m : null]; }, function () { return [k, null]; });
      }));
    }).then(function (pairs) {
      if (seq !== pfSeq) return;
      var prices = {};
      pairs.forEach(function (p) { if (p[1]) prices[p[0]] = p[1]; });
      drawPortfolio(prices);
    });
  }

  function drawPortfolio(prices) {
    var s = E.pfSummary(S.pf, prices), loading = s.rows.length && !Object.keys(prices).length;
    $("#pfTotal").textContent = loading ? "…" : "฿" + money(s.total);
    $("#pfPnl").innerHTML = loading ? "&nbsp;" : '<span class="' + cls(s.pnl) + '">' + (s.pnl >= 0 ? "+" : "") + money(s.pnl) + " บาท (" + pct(s.pnlPct) + ")</span> <span class='muted'>จากเงินตั้งต้น ฿" + money(s.startCash) + "</span>";
    $("#pfCash").textContent = "฿" + money(s.cash);
    $("#pfHold").textContent = loading ? "…" : "฿" + money(s.holdValue);

    $("#holdings").innerHTML = s.rows.length ? '<div class="list">' + s.rows.map(function (r) {
      return '<button class="item" data-pick="' + esc(r.key) + '"><div class="l"><b>' + esc(r.short) + '</b><span class="num">' + qty(r.qty) +
        " · ต้นทุนเฉลี่ย ฿" + price(r.avgCost) + '</span></div><div class="r"><b class="num">' + (r.value == null ? "…" : "฿" + money(r.value)) +
        '</b><span class="num ' + cls(r.pnl) + '">' + (r.pnl == null ? "" : (r.pnl >= 0 ? "+" : "") + money(r.pnl) + " (" + pct(r.pnlPct) + ")") + "</span></div></button>";
    }).join("") + "</div>" : '<div class="empty">ยังไม่มี — ลองซื้อสักตัวดูสิ</div>';

    $("#history").innerHTML = S.pf.history.length ? '<div class="list">' + S.pf.history.slice(0, 40).map(function (h) {
      var d = new Date(h.t);
      return '<div class="item"><div class="l"><b><span class="badge ' + h.side + '">' + (h.side === "buy" ? "ซื้อ" : "ขาย") + "</span>" + esc(h.short) +
        '</b><span>' + d.toLocaleDateString("th-TH", { day: "numeric", month: "short" }) + " " + timeTh(d) + " · ราคา ฿" + price(h.price) + '</span></div><div class="r"><b class="num">฿' + money(h.thb) +
        "</b>" + (h.pnl != null ? '<span class="num ' + cls(h.pnl) + '">' + (h.pnl >= 0 ? "กำไร +" : "ขาดทุน ") + money(h.pnl) + "</span>" : '<span class="num">' + qty(h.qty) + "</span>") + "</div></div>";
    }).join("") + "</div>" : '<div class="empty">ยังไม่มีรายการ</div>';
  }

  function trade(side, all) {
    var amt = parseFloat($("#amount").value);
    if (!all && !(amt > 0)) { toast("ใส่จำนวนเงินก่อน"); $("#amount").focus(); return; }
    var btns = $$("#buyBtn, #sellBtn, #sellAllBtn");
    btns.forEach(function (b) { b.disabled = true; });
    refreshQuote().then(function (q) {
      if (!q || !q.thb) throw new Error("ยังไม่มีราคาเป็นบาท (ดึงอัตราแลกเปลี่ยนไม่ได้) ลองใหม่อีกครั้ง");
      var info = meta(S.ui.market, S.ui.symbol);
      var o = { key: keyOf(S.ui.market, S.ui.symbol), market: S.ui.market, symbol: S.ui.symbol, short: info.short, priceThb: q.thb, amountThb: amt, all: all, feePct: S.settings.feePct };
      if (side === "buy") E.pfBuy(S.pf, o); else E.pfSell(S.pf, o);
      savePf();
      $("#amount").value = "";
      toast((side === "buy" ? "ซื้อ" : "ขาย") + " " + info.short + " (จำลอง) ที่ ฿" + price(q.thb) + " แล้ว");
      renderPaper();
    }).catch(function (e) { toast(e.message || "ทำรายการไม่สำเร็จ"); })
      .then(function () { btns.forEach(function (b) { b.disabled = false; }); });
  }

  // ---------- Backtest ----------
  function fillStrategies() {
    $("#strategy").innerHTML = Object.keys(E.STRATEGIES).map(function (k) { return '<option value="' + k + '">' + E.STRATEGIES[k].label + "</option>"; }).join("");
    $("#strategy").value = S.ui.strategy || "ma_cross";
    renderParams();
  }
  function renderParams() {
    var k = $("#strategy").value, st = E.STRATEGIES[k];
    S.ui.strategy = k; saveUi();
    var term = { ma_cross: "ma", rsi: "rsi", buy_hold: "buyhold" }[k];
    $("#strategyDesc").innerHTML = esc(st.desc) + " " + ti(term);
    $("#params").innerHTML = st.params.map(function (p) {
      return '<label class="field"><span>' + esc(p.label) + '</span><input type="number" inputmode="numeric" data-p="' + p.key + '" value="' + p.value + '" min="' + p.min + '" max="' + p.max + '"></label>';
    }).join("");
  }

  function runBacktest() {
    var k = $("#strategy").value, days = +$("#btDays").value, cash = parseFloat($("#btCash").value) || 100000, over = {};
    $$("#params [data-p]").forEach(function (i) { over[i.dataset.p] = +i.value; });
    if (k === "ma_cross" && over.fast >= over.slow) { toast("เส้นเร็วต้องน้อยกว่าเส้นช้า"); return; }
    if (k === "rsi" && over.low >= over.high) { toast("เส้นล่างต้องน้อยกว่าเส้นบน"); return; }
    var btn = $("#btRun"); btn.disabled = true; btn.textContent = "กำลังคำนวณ…";
    var m = S.ui.market, sym = S.ui.symbol, info = meta(m, sym);
    M.history(m, sym, days).then(function (h) {
      if (h.candles.length < 30) throw new Error("ข้อมูลย้อนหลังของ " + info.short + " ยังน้อยเกินไป");
      var r = E.backtest(h.candles, k, over, { cash: cash, feePct: S.settings.feePct }), s = r.stats;
      var short = h.candles.length < days * 0.6 && m === "crypto";
      $("#btRange").textContent = info.short + " · " + window.shortDateTh(s.start) + " – " + window.shortDateTh(s.end) + (short ? " (มีข้อมูลเท่านี้)" : "");
      var cards = [
        ["ผลตอบแทนกลยุทธ์", pct(s.returnPct), cls(s.returnPct), "backtest"],
        ["ถ้าซื้อแล้วถือเฉย ๆ", pct(s.bhReturnPct), cls(s.bhReturnPct), "buyhold"],
        ["เงินตอนจบ", "฿" + money(s.final), "", ""],
        ["ร่วงหนักสุด", pct(s.maxDDPct), "down", "drawdown"],
        ["อัตราชนะ", s.winRatePct == null ? "—" : Math.round(s.winRatePct) + "% (" + s.closedTrades + " รอบ)", "", "winrate"],
        ["เวลาที่ถือของ", Math.round(s.exposurePct) + "%", "", "exposure"]
      ];
      $("#btStats").innerHTML = cards.map(function (c) {
        return '<div class="stat"><div class="v num ' + c[2] + '">' + c[1] + '</div><div class="k">' + c[0] + " " + ti(c[3]) + "</div></div>";
      }).join("");
      $("#btSummary").innerHTML = "<b>สรุปง่าย ๆ</b><ul>" + E.explainBacktest(r, k).map(function (l) { return "<li>" + esc(l) + "</li>"; }).join("") + "</ul>";
      $("#btTrades").innerHTML = r.trades.length ? '<div class="list">' + r.trades.map(function (t) {
        return '<div class="item"><div class="l"><b><span class="badge ' + t.side + '">' + (t.side === "buy" ? "ซื้อ" : "ขาย") + "</span>" + window.shortDateTh(t.t) +
          '</b></div><div class="r"><b class="num">' + price(t.price) + " " + h.currency + "</b>" + (t.pnlPct != null ? '<span class="num ' + cls(t.pnlPct) + '">' + pct(t.pnlPct) + "</span>" : "") + "</div></div>";
      }).join("") + "</div>" : '<div class="empty">ไม่มีการซื้อขาย</div>';
      $("#btResult").hidden = false;
      if (S.charts.bt) S.charts.bt.destroy();
      S.charts.bt = new window.LineChart($("#btChart"), {
        labels: r.curve.map(function (p) { return p.t; }),
        series: [
          { values: r.curve.map(function (p) { return p.bh; }), color: "#f2b84b", label: "ถือเฉย ๆ", width: 1.6 },
          { values: r.curve.map(function (p) { return p.equity; }), color: "#3fb6a8", label: "กลยุทธ์" }
        ],
        fmt: shortMoney
      });
      $("#btResult").scrollIntoView({ behavior: "smooth", block: "start" });
    }).catch(function (e) { toast(e.message || "ทดสอบไม่สำเร็จ"); })
      .then(function () { btn.disabled = false; btn.textContent = "ทดสอบ"; });
  }

  // ---------- DCA ----------
  function runDca() {
    var amt = parseFloat($("#dcaAmt").value), days = +$("#dcaDays").value;
    var freq = ($("#dcaFreq .on") || {}).dataset ? $("#dcaFreq .on").dataset.freq : "weekly";
    if (!(amt > 0)) { toast("ใส่จำนวนเงินต่องวดก่อน"); return; }
    var btn = $("#dcaRun"); btn.disabled = true; btn.textContent = "กำลังคำนวณ…";
    var m = S.ui.market, sym = S.ui.symbol, info = meta(m, sym);
    Promise.all([M.history(m, sym, days), M.fx()]).then(function (r) {
      var h = r[0]; S.fx = r[1];
      var k = mult(h.currency);
      if (!k) throw new Error("ดึงอัตราแลกเปลี่ยนไม่ได้ ลองใหม่อีกครั้ง");
      if (h.candles.length < 20) throw new Error("ข้อมูลย้อนหลังของ " + info.short + " ยังน้อยเกินไป");
      var d = E.dca(h.candles, { amount: amt, freq: freq, feePct: S.settings.feePct, priceMult: k }), s = d.stats;
      $("#dcaRange").textContent = info.short + " · " + window.shortDateTh(s.start) + " – " + window.shortDateTh(s.end);
      var cards = [
        ["ใส่เงินไปทั้งหมด", "฿" + money(s.invested), "", ""],
        ["มูลค่าตอนนี้", "฿" + money(s.value), cls(s.profit), "pnl"],
        ["กำไร/ขาดทุน", (s.profit >= 0 ? "+" : "") + money(s.profit) + " (" + pct(s.profitPct) + ")", cls(s.profit), "pnl"],
        ["ต้นทุนเฉลี่ย", "฿" + price(s.avgCost), "", "avgcost"],
        ["ซื้อไปทั้งหมด", s.buys + " ครั้ง · " + qty(s.units) + " " + info.short, "", ""],
        ["ถ้าซื้อก้อนเดียววันแรก", pct(s.lumpPct), cls(s.lumpPct), "lumpsum"]
      ];
      $("#dcaStats").innerHTML = cards.map(function (c) {
        return '<div class="stat"><div class="v num ' + c[2] + '">' + c[1] + '</div><div class="k">' + c[0] + " " + ti(c[3]) + "</div></div>";
      }).join("");
      $("#dcaSummary").innerHTML = "<b>สรุปง่าย ๆ</b><ul>" + E.explainDca(d, info.short).map(function (l) { return "<li>" + esc(l) + "</li>"; }).join("") + "</ul>";
      $("#dcaResult").hidden = false;
      if (S.charts.dca) S.charts.dca.destroy();
      S.charts.dca = new window.LineChart($("#dcaChart"), {
        labels: d.points.map(function (p) { return p.t; }),
        series: [
          { values: d.points.map(function (p) { return p.invested; }), color: "#8c9bb0", label: "ใส่ไป", dash: "4 3", width: 1.6 },
          { values: d.points.map(function (p) { return p.value; }), color: "#3fb6a8", label: "มูลค่า", fill: true }
        ],
        fmt: shortMoney
      });
      $("#dcaResult").scrollIntoView({ behavior: "smooth", block: "start" });
    }).catch(function (e) { toast(e.message || "จำลองไม่สำเร็จ"); })
      .then(function () { btn.disabled = false; btn.textContent = "จำลอง DCA"; });
  }

  // ---------- แผ่นด้านล่าง (คำศัพท์ / ตั้งค่า / สำรองพอร์ต) ----------
  function openSheet(html) {
    $("#sheetBody").innerHTML = html;
    $("#sheet").hidden = false; $("#sheetBack").hidden = false;
  }
  function closeSheet() { $("#sheet").hidden = true; $("#sheetBack").hidden = true; }

  function termHtml(key) {
    var g = G[key];
    return "<h3>" + esc(g.term) + "</h3><p>" + esc(g.text) + "</p>" + (g.tip ? '<p class="tip">' + esc(g.tip) + "</p>" : "");
  }

  function openSettings() {
    openSheet('<h3>ตั้งค่า</h3>' +
      '<label class="field"><span>ค่าธรรมเนียมสมมติต่อครั้ง (%) ' + ti("fee") + '</span><input type="number" id="setFee" step="0.01" min="0" max="5" value="' + S.settings.feePct + '"></label>' +
      '<label class="field"><span>เงินตั้งต้นเมื่อกด "เริ่มใหม่" (บาท)</span><input type="number" id="setCash" min="1000" value="' + S.settings.startCash + '"></label>' +
      '<button class="btn primary full" id="setSave">บันทึก</button>' +
      '<p class="fine">ราคาคริปโต: Binance (USDT) แปลงเป็นบาทด้วยอัตรา USD/THB' + (S.fx && S.fx.rate ? " (ตอนนี้ " + nf(S.fx.rate, 2) + " บาท, แหล่ง: " + esc(S.fx.source) + ")" : "") +
      ' · ราคาหุ้น: Yahoo Finance อัปเดตวันละ 2 รอบ · ข้อมูลพอร์ตเก็บในเครื่องนี้เท่านั้น</p>');
  }

  function openBackup() {
    var code = "";
    try { code = btoa(unescape(encodeURIComponent(JSON.stringify(S.pf)))); } catch (e) { code = ""; }
    openSheet("<h3>สำรอง / กู้คืนพอร์ต</h3>" +
      "<p>พอร์ตจำลองเก็บอยู่ในเครื่องนี้เท่านั้น ถ้าอยากย้ายไปมือถือหรือ Mac อีกเครื่อง ให้คัดลอกรหัสด้านล่างไปวางที่ช่องกู้คืนในเครื่องนั้น</p>" +
      '<textarea id="bkOut" readonly>' + esc(code) + "</textarea>" +
      '<button class="btn ghost full" id="bkCopy">คัดลอกรหัสสำรอง</button>' +
      '<p style="margin-top:16px">กู้คืน: วางรหัสที่นี่ (พอร์ตในเครื่องนี้จะถูกแทนที่)</p>' +
      '<textarea id="bkIn" placeholder="วางรหัสสำรองที่นี่"></textarea>' +
      '<button class="btn primary full" id="bkRestore">กู้คืนพอร์ต</button>');
  }

  function renderGlossary() {
    $("#glossaryList").innerHTML = Object.keys(G).map(function (k) {
      var g = G[k];
      return '<div class="card gterm" id="term-' + k + '"><h3>' + esc(g.term) + "</h3><p>" + esc(g.text) + "</p>" + (g.tip ? '<p class="tip">' + esc(g.tip) + "</p>" : "") + "</div>";
    }).join("");
  }

  // ---------- ปุ่มต่าง ๆ ----------
  function bind() {
    document.addEventListener("click", function (e) {
      var t = e.target.closest("[data-term]");
      if (t) { e.preventDefault(); openSheet(termHtml(t.dataset.term)); return; }
      var tab = e.target.closest("[data-tab]");
      if (tab) { setTab(tab.dataset.tab); return; }
      var mk = e.target.closest("#marketSeg [data-market]");
      if (mk) { S.ui.market = mk.dataset.market; S.ui.symbol = null; saveUi(); fillSymbols(); onSymbolChange(); return; }
      var rg = e.target.closest("#rangeChips [data-days]");
      if (rg) { S.ui.range = +rg.dataset.days; saveUi(); loadOverview(); return; }
      var ac = e.target.closest("#amtChips [data-amt]");
      if (ac) { $("#amount").value = ac.dataset.amt === "all" ? Math.floor(S.pf.cash * 100) / 100 : ac.dataset.amt; return; }
      var fq = e.target.closest("#dcaFreq [data-freq]");
      if (fq) { $$("#dcaFreq button").forEach(function (b) { b.classList.toggle("on", b === fq); }); return; }
      var pick = e.target.closest("[data-pick]");
      if (pick) { var p = pick.dataset.pick.split(":"); selectSymbol(p[0], p.slice(1).join(":")); window.scrollTo({ top: 0, behavior: "smooth" }); return; }
      var id = e.target.closest("button") && e.target.closest("button").id;
      if (id === "sheetX") closeSheet();
      else if (id === "setSave") {
        var f = parseFloat($("#setFee").value), c = parseFloat($("#setCash").value);
        if (f >= 0 && f <= 5) S.settings.feePct = f;
        if (c >= 1000) S.settings.startCash = c;
        store.set("atl-settings", S.settings); $("#feeLabel").textContent = S.settings.feePct;
        closeSheet(); toast("บันทึกแล้ว");
      } else if (id === "bkCopy") {
        var ta = $("#bkOut"); ta.select();
        (navigator.clipboard ? navigator.clipboard.writeText(ta.value) : Promise.reject()).then(function () { toast("คัดลอกแล้ว"); }, function () { document.execCommand("copy"); toast("คัดลอกแล้ว"); });
      } else if (id === "bkRestore") {
        try {
          var pf = JSON.parse(decodeURIComponent(escape(atob($("#bkIn").value.trim()))));
          if (!pf || typeof pf.cash !== "number" || !pf.holdings) throw new Error();
          S.pf = pf; savePf(); closeSheet(); renderPaper(); toast("กู้คืนพอร์ตแล้ว");
        } catch (err) { toast("รหัสไม่ถูกต้อง ลองคัดลอกใหม่อีกครั้ง"); }
      }
    });
    $("#sheetBack").addEventListener("click", closeSheet);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeSheet(); });
    $("#symbol").addEventListener("change", function () { S.ui.symbol = this.value; saveUi(); onSymbolChange(); });
    $("#refreshBtn").addEventListener("click", function () { M.clearCache(); onSymbolChange(); });
    $("#settingsBtn").addEventListener("click", openSettings);
    $("#buyBtn").addEventListener("click", function () { trade("buy", false); });
    $("#sellBtn").addEventListener("click", function () { trade("sell", false); });
    $("#sellAllBtn").addEventListener("click", function () { trade("sell", true); });
    $("#backupBtn").addEventListener("click", openBackup);
    $("#resetBtn").addEventListener("click", function () {
      if (!confirm("ล้างพอร์ตจำลอง แล้วเริ่มใหม่ด้วยเงิน " + money(S.settings.startCash) + " บาท?")) return;
      S.pf = E.newPortfolio(S.settings.startCash); savePf(); renderPaper(); toast("เริ่มพอร์ตใหม่แล้ว");
    });
    $("#strategy").addEventListener("change", renderParams);
    $("#btRun").addEventListener("click", runBacktest);
    $("#dcaRun").addEventListener("click", runDca);

    // อัปเดตราคาคริปโตทุก 30 วินาทีตอนเปิดหน้าจออยู่
    setInterval(function () {
      if (document.visibilityState === "visible" && S.ui.market === "crypto" && $("#sheet").hidden) refreshQuote().catch(function () {});
    }, 30000);
  }

  // ---------- เริ่มต้น ----------
  fetch("symbols.json", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (sy) {
    S.symbols = sy;
    if (!sy[S.ui.market]) S.ui.market = "crypto";
    fillSymbols(); fillStrategies(); renderGlossary(); bind();
    setTab(S.ui.tab || "overview");
    refreshQuote().catch(function () {});
  }).catch(function () {
    document.body.insertAdjacentHTML("afterbegin", '<p style="padding:20px;text-align:center">โหลดแอปไม่สำเร็จ ลองรีเฟรชหน้าอีกครั้ง</p>');
  });
})();
