"""
update_data.py — ดึงราคาหุ้นรายวัน + อัตราแลกเปลี่ยน USD/THB เก็บเป็นไฟล์ JSON ในโฟลเดอร์ data/
GitHub Actions รันไฟล์นี้ให้อัตโนมัติวันละ 2 รอบ (ดู .github/workflows/update-data.yml)
รันเองในเครื่องก็ได้:  pip install yfinance requests && python scripts/update_data.py

ถ้าดึงตัวไหนไม่สำเร็จ จะเก็บไฟล์เดิมไว้ ไม่ลบทิ้ง
"""
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
STOCKS = os.path.join(DATA, "stocks")
YEARS = "6y"


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def file_name(symbol):
    return re.sub(r"[^A-Za-z0-9]", "_", symbol)


def write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def fetch_closes(yf, symbol, tries=3):
    last = None
    for i in range(tries):
        try:
            hist = yf.Ticker(symbol).history(period=YEARS, interval="1d", auto_adjust=False)
            if hist is None or hist.empty:
                raise ValueError("ไม่มีข้อมูล")
            rows = []
            for idx, close in hist["Close"].items():
                if close == close and close > 0:  # ตัด NaN
                    rows.append([idx.strftime("%Y-%m-%d"), round(float(close), 6)])
            if len(rows) < 20:
                raise ValueError("ข้อมูลน้อยเกินไป")
            return rows
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(3 * (i + 1))
    raise RuntimeError(str(last))


def update_fx(yf):
    rate, source = None, None
    try:
        h = yf.Ticker("THB=X").history(period="5d", interval="1d")
        if not h.empty:
            rate, source = float(h["Close"].dropna().iloc[-1]), "Yahoo Finance"
    except Exception as e:  # noqa: BLE001
        print("fx yfinance failed:", e)
    if not rate:
        try:
            import requests
            j = requests.get("https://open.er-api.com/v6/latest/USD", timeout=15).json()
            rate, source = float(j["rates"]["THB"]), "open.er-api.com"
        except Exception as e:  # noqa: BLE001
            print("fx fallback failed:", e)
    if rate and 10 < rate < 100:
        write_json(os.path.join(DATA, "fx.json"), {"usdthb": round(rate, 4), "source": source, "updated": now()})
        print("fx USD/THB =", round(rate, 4), "from", source)
        return True
    return False


def main():
    import yfinance as yf

    os.makedirs(STOCKS, exist_ok=True)
    with open(os.path.join(ROOT, "symbols.json"), encoding="utf-8") as f:
        symbols = json.load(f)

    ok, failed = [], []
    for market in ("stock_th", "stock_us"):
        for s in symbols.get(market, []):
            sym = s["symbol"]
            try:
                rows = fetch_closes(yf, sym)
                write_json(os.path.join(STOCKS, file_name(sym) + ".json"), {
                    "symbol": sym,
                    "currency": "THB" if market == "stock_th" else "USD",
                    "updated": now(),
                    "candles": rows,
                })
                ok.append(sym)
                print("ok", sym, len(rows), "days, last", rows[-1])
            except Exception as e:  # noqa: BLE001
                failed.append(sym)
                print("FAILED", sym, e)
            time.sleep(1)

    fx_ok = update_fx(yf)
    write_json(os.path.join(DATA, "meta.json"), {"updated": now(), "ok": ok, "failed": failed, "fx": fx_ok})
    print(f"done: {len(ok)} ok, {len(failed)} failed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
